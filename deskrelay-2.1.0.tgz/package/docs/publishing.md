# 对外发布与 GitHub 提交

DeskRelay 可能由多个 Agent 并行修改，但一次正式版本只能由一个用户明确指定的发布 Agent 负责。普通开发 Agent 只交付本地 commit，不推送、不合并、不改版本号、不发版。

发布有三条固定边界：

1. 开发 Agent 在各自分支和 worktree 中修改、验证并提交；
2. 唯一发布 Agent 按明确 commit SHA 集成、整理版本说明并完成验收；
3. GitHub 的 fetch、公开 commit、push、tag 和远端验真全部在专用发布服务器完成。

维护者 Mac 不得直接向 GitHub 执行 `git push`、`gh repo sync`、GitHub API 上传或其他 Git 写操作，也不得在服务器失败后改为本机直推。完整角色与交接规则见 [agent-release-workflow.md](agent-release-workflow.md)。

## 1. 发布 Agent 接管前检查

普通开发 Agent 到这里已经停止：它们只交付分支、commit SHA、改动范围和验证结果。

发布 Agent 必须检查：

```bash
git status --short
git diff --check
git worktree list --porcelain
git branch --all --verbose --no-abbrev
git log --oneline --decorate -30
```

建立候选提交表，确认每个纳入版本的功能都有明确 SHA、来源分支、用户可见变化和测试结果。不得直接发布共享工作树中的未提交文件，也不得用“某个目录看起来最新”代替 commit 边界。

集成完成后冻结发布基线。若 HEAD、候选提交、版本说明或关键配置发生变化，必须重新检查发布边界。

## 2. 准备版本说明

只有发布 Agent 可以更新正式版本号、锁文件、`docs/releases/`、release commit 和 tag 候选。

中文版本记录必须使用 [releases/TEMPLATE_CN.md](releases/TEMPLATE_CN.md)，并遵守：

- 用普通中文说明用户现在能做什么；
- 说明之前会遇到什么问题、现在如何改善；
- 说明是否需要重新登录、重启、修改配置或重新发送；
- 明确仍然存在的限制；
- 不写内部类名、字段名、文件路径、提交 SHA 和测试命令；
- 不使用“优化若干”“修复问题”“全面提升”等空泛说法。

技术细节、测试证据和 commit 清单放在发布验收报告或 commit body 中。

## 3. 发布前验证

至少运行：

```bash
git diff --check
npm run privacy:check
npm run lint
npm run typecheck:src
bun test test
npm run build
npm pack --dry-run --json
```

根据改动范围追加：

```bash
npm audit --omit=dev
npm publish --dry-run --access public
npm run smoke:global -- --purge-global --clean-cache
```

确认：

- lint、类型检查、测试和构建通过；
- tarball 包名、版本和发布说明一致；
- 包内不含 `.env`、私钥、日志、运行状态、附件、测试源码、`node_modules` 或本机路径；
- 所有公开位图都经过重新审查；
- 任何失败都保留为失败，不能用局部检查替代完整验收。

## 4. 导出无历史公开快照

在源仓库外选择一个不存在或为空的目录：

```bash
npm run public:snapshot -- ../DeskRelay-public
cd ../DeskRelay-public
npm install
npm run quality
npm pack --dry-run --json
```

快照脚本不会复制 `.git`、本地环境文件、密钥、`~/.deskrelay`、日志、附件、缓存、`dist` 或 `node_modules`。从 macOS 打包给 Linux 时必须设置 `COPYFILE_DISABLE=1` 并使用 `tar --no-xattrs`，再检查归档不存在 `._*` 文件。

本机快照目录不要执行 `git init` 或添加 GitHub remote。它只是经过审核的公开文件集合，不是发布仓库。

## 5. 专用发布服务器

每个公开仓库使用独立目录和独立 GitHub deploy key，避免影响其他项目。例如：

```text
~/deskrelay-github-relay/
  incoming/       # 临时快照，0700
  repo.git/       # bare 仓库
  work/           # 每次发布的临时工作树
  push.log        # 发布审计，0600
```

私钥只保存在服务器，权限为 `0600`，不得复制回开发电脑或写入仓库、脚本参数、日志和聊天记录。

服务器 helper 必须：

- 先 fetch GitHub 当前 `main`；
- 以远端当前提交创建隔离临时工作树；
- 再次运行隐私检查；
- 创建公开 commit 并执行 fast-forward push；
- 拒绝 non-fast-forward 和强推；
- 用 `git ls-remote` 验证最终 SHA；
- 清理本次临时文件；
- 不触碰服务器上的其他项目。

## 6. 标准发布命令

仓库提供 `scripts/publish-github-via-server.mjs`。机器地址、SSH 用户、私钥路径和远端 helper 路径必须通过参数或本机环境变量提供，不能硬编码进仓库。

```bash
node scripts/publish-github-via-server.mjs \
  --server user@publish.example.com \
  --identity ~/.ssh/deskrelay_publish_ed25519 \
  --remote-helper ~/bin/deskrelay-github-publish-remote \
  --message "chore: release X.Y.Z"
```

该命令在本机只做隐私检查、生成公开快照和上传归档；GitHub fetch、公开 commit、push 和验真在服务器执行。远端在 fetch 与 push 之间出现新提交时，本次发布必须失败并重新开始，不能强推。

可复用的服务器 helper 模板位于 `deploy/github-publish-server/deskrelay-github-publish-remote`。

## 7. npm 发布

GitHub 发布和 npm 发布是两件事。没有用户明确授权时，不执行真实 `npm publish`。

正式发布后必须从 npm registry 查询真实版本和 dist-tag，并重新安装执行 smoke。不能仅凭本地发布命令返回成功就声称 npm 已发布。

## 8. 发布后验收

发布 Agent 必须核对：

- GitHub 远端 SHA 与服务器发布结果一致；
- npm registry 版本正确（如果本次包含 npm 发布）；
- 本机安装版本和 `/app-version` 正确；
- 正式网页、API、Relay 和设备在线链路正常；
- 版本记录没有把未验证事项写成已完成；
- 服务器临时快照已清理，其他项目未受影响。

本机私有开发提交与服务器创建的公开 commit SHA 可以不同；以公开文件树、服务器审计结果和 GitHub 远端 SHA 作为正式发布证据。
